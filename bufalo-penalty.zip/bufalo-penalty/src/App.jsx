import React, { useState, useEffect, useRef, useCallback } from 'react'

/* =====================================================================
   BÚFALO PENALTY — Hyper Casual de Futebol (React + Vite + Tailwind)
   "Chuta forte ou volta pro banco!"  —  tudo em um arquivo: App.jsx
   ===================================================================== */

/* ---------------------------------------------------------------------
   ADSENSE: liga/desliga TODOS os anúncios do jogo de uma vez
   --------------------------------------------------------------------- */
const ADS_ENABLED = true

/* --------------------------- CONFIG DO JOGO -------------------------- */
const LIVES_START = 3
const COINS_PER_GOAL = 10
const GOALS_PER_LEVEL = 5

// Área do gol em % do campo (usada na colisão bola x gol)
const GOAL = { left: 13, right: 87, top: 12, bottom: 41 }
const BALL_HOME = { x: 50, y: 84 }
const KEEPER_SPOTS = { left: 27, center: 50, right: 73 }

const SKINS = [
  { id: 'padrao', name: 'Bola Padrão', price: 0, emoji: '⚽', ring: '#ffffff' },
  { id: 'fogo', name: 'Bola de Fogo', price: 500, emoji: '🔥', ring: '#ff6a00' },
  { id: 'champions', name: 'Bola Champions', price: 1500, emoji: '⭐', ring: '#3ba7ff' },
]

/* ------------------- PERSISTÊNCIA (localStorage) -------------------- */
const LS = {
  get(key, fallback) {
    try {
      const raw = localStorage.getItem(key)
      return raw === null ? fallback : JSON.parse(raw)
    } catch {
      return fallback
    }
  },
  set(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value))
    } catch {
      /* modo privado ou storage cheio: ignora */
    }
  },
}

/* ------------------------------- ÁUDIO ------------------------------ */
// Sons gerados via WebAudio (sem arquivos externos):
// "MUH" do búfalo no gol, torcida, chute, moeda e som de erro.
function useSound() {
  const ctxRef = useRef(null)

  const ensure = useCallback(() => {
    if (typeof window === 'undefined') return null
    const AC = window.AudioContext || window.webkitAudioContext
    if (!AC) return null
    if (!ctxRef.current) ctxRef.current = new AC()
    if (ctxRef.current.state === 'suspended') ctxRef.current.resume()
    return ctxRef.current
  }, [])

  const blip = useCallback(
    (freq = 660, dur = 0.12, type = 'square', vol = 0.18) => {
      const ctx = ensure()
      if (!ctx) return
      const t = ctx.currentTime
      const osc = ctx.createOscillator()
      const gain = ctx.createGain()
      osc.type = type
      osc.frequency.setValueAtTime(freq, t)
      gain.gain.setValueAtTime(0.0001, t)
      gain.gain.linearRampToValueAtTime(vol, t + 0.02)
      gain.gain.exponentialRampToValueAtTime(0.0001, t + dur)
      osc.connect(gain).connect(ctx.destination)
      osc.start(t)
      osc.stop(t + dur + 0.02)
    },
    [ensure]
  )

  // som "MUH" do búfalo
  const muh = useCallback(() => {
    const ctx = ensure()
    if (!ctx) return
    const t = ctx.currentTime
    const osc = ctx.createOscillator()
    const gain = ctx.createGain()
    const filter = ctx.createBiquadFilter()
    osc.type = 'sawtooth'
    osc.frequency.setValueAtTime(150, t)
    osc.frequency.exponentialRampToValueAtTime(78, t + 0.55)
    filter.type = 'lowpass'
    filter.frequency.value = 900
    gain.gain.setValueAtTime(0.0001, t)
    gain.gain.linearRampToValueAtTime(0.35, t + 0.06)
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.7)
    osc.connect(filter).connect(gain).connect(ctx.destination)
    osc.start(t)
    osc.stop(t + 0.72)
  }, [ensure])

  // som de torcida (ruído filtrado)
  const crowd = useCallback(
    (duration = 1.4, volume = 0.2) => {
      const ctx = ensure()
      if (!ctx) return
      const t = ctx.currentTime
      const buffer = ctx.createBuffer(1, Math.floor(ctx.sampleRate * duration), ctx.sampleRate)
      const data = buffer.getChannelData(0)
      for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * 0.7
      const src = ctx.createBufferSource()
      src.buffer = buffer
      const filter = ctx.createBiquadFilter()
      filter.type = 'bandpass'
      filter.frequency.value = 1100
      filter.Q.value = 0.7
      const gain = ctx.createGain()
      gain.gain.setValueAtTime(0.0001, t)
      gain.gain.linearRampToValueAtTime(volume, t + 0.18)
      gain.gain.exponentialRampToValueAtTime(0.0001, t + duration)
      src.connect(filter).connect(gain).connect(ctx.destination)
      src.start(t)
    },
    [ensure]
  )

  const kick = useCallback(() => blip(220, 0.1, 'triangle', 0.25), [blip])
  const coin = useCallback(() => {
    blip(880, 0.08)
    setTimeout(() => blip(1320, 0.1), 70)
  }, [blip])
  const fail = useCallback(() => {
    blip(300, 0.18, 'sawtooth', 0.16)
    setTimeout(() => blip(180, 0.32, 'sawtooth', 0.16), 130)
  }, [blip])

  return { muh, crowd, kick, coin, fail, unlock: ensure }
}

/* ============================== UI: LOGO ============================= */
function Logo({ small = false }) {
  return (
    <div className="flex flex-col items-center">
      <div className={small ? 'text-4xl' : 'text-6xl'} aria-hidden="true">
        <span className="inline-block -rotate-6">🐃</span>
        <span className="inline-block">⚽</span>
      </div>
      <h1
        className={`font-game text-stroke text-center font-extrabold leading-none ${
          small ? 'text-2xl' : 'text-4xl sm:text-5xl'
        }`}
      >
        <span className="text-amarelo">BÚFALO</span> <span className="text-white">PENALTY</span>
      </h1>
      {!small && (
        <p className="mt-2 text-center text-sm font-semibold text-amber-100">
          “Chuta forte ou volta pro banco!”
        </p>
      )}
    </div>
  )
}

/* ========================= UI: BOTÃO GRANDE ========================= */
function BigButton({ children, onClick, tone = 'yellow', disabled = false, className = '' }) {
  const tones = {
    yellow: 'bg-amarelo text-bufalo border-yellow-600 active:bg-yellow-300',
    brown: 'bg-bufalo text-amarelo border-yellow-900 active:bg-bufaloClaro',
    green: 'bg-campo text-white border-green-900 active:bg-campoEscuro',
    dark: 'bg-black/60 text-white border-white/20 active:bg-black/80',
  }
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={`w-full rounded-2xl border-b-4 px-5 py-4 text-lg font-extrabold uppercase tracking-wide shadow-lg transition-transform active:translate-y-1 disabled:opacity-40 ${tones[tone]} ${className}`}
    >
      {children}
    </button>
  )
}

/* ==================== UI: VIDAS (CHIFRES DE BÚFALO) ================= */
function Horn({ filled }) {
  return (
    <svg viewBox="0 0 32 32" className={`h-7 w-7 ${filled ? '' : 'opacity-25 grayscale'}`}>
      <path
        d="M4 6c8 1 13 5 16 11 2 4 5 6 8 6-3 4-8 4-12 1C11 20 7 14 4 6z"
        fill={filled ? '#f3e2c7' : '#888888'}
        stroke="#4a2a10"
        strokeWidth="2"
        strokeLinejoin="round"
      />
    </svg>
  )
}

function Lives({ lives }) {
  return (
    <div className="flex items-center gap-1">
      {[0, 1, 2].map((i) => (
        <Horn key={i} filled={i < lives} />
      ))}
      {lives > 3 && <span className="ml-1 text-sm font-bold text-white">+{lives - 3}</span>}
    </div>
  )
}

/* ======================= UI: BANNER ADSENSE (FIXO) ================== */
function BannerAd() {
  if (!ADS_ENABLED) return null
  return (
    // ==============================================================
    // ADSENSE — BANNER FIXO NO RODAPÉ
    // Cole o código do bloco de anúncio dentro desta div (#banner-ad)
    // ==============================================================
    <div
      id="banner-ad"
      className="fixed bottom-0 left-0 z-40 flex h-14 w-full items-center justify-center bg-black/50 text-[11px] uppercase tracking-widest text-white/40"
    >
      {/* COLAR CODIGO ADSENSE BANNER AQUI */}
      espaço do anúncio
    </div>
  )
}

/* ====================== UI: ESTÁDIO / CAMPO / GOL =================== */
function Stadium({ children }) {
  return (
    <div className="absolute inset-0 overflow-hidden">
      {/* arquibancada */}
      <div className="absolute inset-x-0 top-0 h-[26%] bg-gradient-to-b from-slate-800 to-slate-600">
        <div
          className="h-full w-full opacity-70"
          style={{
            backgroundImage:
              'radial-gradient(circle, #ffc71f 1.4px, transparent 1.6px), radial-gradient(circle, #ffffff 1.2px, transparent 1.4px)',
            backgroundSize: '14px 14px, 22px 18px',
            backgroundPosition: '0 0, 7px 9px',
          }}
        />
      </div>
      {/* faixa de publicidade do estádio */}
      <div className="absolute inset-x-0 top-[26%] flex h-[4%] items-center justify-center bg-bufalo text-[9px] font-bold uppercase tracking-[0.3em] text-amarelo">
        búfalo penalty
      </div>
      {/* gramado com listras */}
      <div className="absolute inset-x-0 bottom-0 top-[30%] bg-campo">
        <div
          className="h-full w-full"
          style={{
            backgroundImage:
              'repeating-linear-gradient(to bottom, rgba(255,255,255,0.06) 0 22px, rgba(0,0,0,0.06) 22px 44px)',
          }}
        />
      </div>
      {/* marca do pênalti */}
      <div className="absolute left-1/2 top-[70%] h-2 w-2 -translate-x-1/2 rounded-full bg-white/80" />
      <div className="absolute left-1/2 top-[52%] h-[22%] w-[70%] -translate-x-1/2 rounded-b-[40%] border-2 border-white/50 border-t-0" />
      {children}
    </div>
  )
}

function GoalFrame() {
  return (
    <div
      className="absolute"
      style={{
        left: `${GOAL.left}%`,
        top: `${GOAL.top}%`,
        width: `${GOAL.right - GOAL.left}%`,
        height: `${GOAL.bottom - GOAL.top}%`,
      }}
    >
      {/* rede */}
      <div
        className="absolute inset-0 rounded-t-md bg-black/25"
        style={{
          backgroundImage:
            'repeating-linear-gradient(to right, rgba(255,255,255,0.35) 0 1px, transparent 1px 12px), repeating-linear-gradient(to bottom, rgba(255,255,255,0.35) 0 1px, transparent 1px 12px)',
        }}
      />
      {/* travessão e postes */}
      <div className="absolute -top-1 left-0 h-2 w-full rounded bg-white shadow" />
      <div className="absolute -left-1 top-0 h-full w-2 rounded bg-white shadow" />
      <div className="absolute -right-1 top-0 h-full w-2 rounded bg-white shadow" />
    </div>
  )
}

/* ========================== UI: GOLEIRO (IA) ======================== */
function Keeper({ x, dive, jumping }) {
  const tilt = dive === 'left' ? -55 : dive === 'right' ? 55 : 0
  return (
    <div
      className="absolute z-10 transition-all duration-300 ease-out"
      style={{
        left: `${x}%`,
        top: `${GOAL.bottom - 2}%`,
        transform: `translate(-50%, -100%) rotate(${jumping ? tilt : 0}deg) translateY(${
          jumping && dive === 'center' ? '-10%' : '0'
        })`,
      }}
    >
      <div className="flex flex-col items-center">
        <div className="text-4xl drop-shadow-lg" aria-hidden="true">
          🧑‍🦱
        </div>
        <div className="-mt-2 h-6 w-9 rounded-b-md bg-orange-500 ring-2 ring-black/30" />
        <div className="h-3 w-9 rounded-b bg-slate-900/80" />
      </div>
    </div>
  )
}

/* ============================= UI: BOLA ============================= */
function Ball({ x, y, scale, skin, spin }) {
  return (
    <div
      className="pointer-events-none absolute z-20"
      style={{
        left: `${x}%`,
        top: `${y}%`,
        transform: `translate(-50%, -50%) scale(${scale}) rotate(${spin}deg)`,
      }}
    >
      <div
        className="flex h-11 w-11 items-center justify-center rounded-full bg-white text-2xl shadow-xl"
        style={{ boxShadow: `0 0 18px ${skin.ring}, 0 6px 12px rgba(0,0,0,0.35)` }}
      >
        {skin.emoji}
      </div>
    </div>
  )
}

/* ============================ APP PRINCIPAL ========================= */
export default function App() {
  const sound = useSound()
  const fieldRef = useRef(null)

  // telas: 'home' | 'game' | 'over' | 'shop'
  const [screen, setScreen] = useState('home')

  // progresso salvo
  const [best, setBest] = useState(() => LS.get('bp_best', 0))
  const [coins, setCoins] = useState(() => LS.get('bp_coins', 0))
  const [skinId, setSkinId] = useState(() => LS.get('bp_skin', 'padrao'))
  const [owned, setOwned] = useState(() => LS.get('bp_owned', ['padrao']))

  // partida atual
  const [score, setScore] = useState(0)
  const [lives, setLives] = useState(LIVES_START)
  const [phase, setPhase] = useState('aim') // 'aim' | 'shooting' | 'result'
  const [message, setMessage] = useState(null)
  const [shake, setShake] = useState(false)
  const [particles, setParticles] = useState([])
  const [adWatched, setAdWatched] = useState(false)

  const [ball, setBall] = useState({ ...BALL_HOME, scale: 1, spin: 0 })
  const [keeper, setKeeper] = useState({ x: KEEPER_SPOTS.center, dive: 'center', jumping: false })
  const [drag, setDrag] = useState(null)

  const rafRef = useRef(null)
  const timersRef = useRef([])
  const level = Math.floor(score / GOALS_PER_LEVEL) + 1
  const skin = SKINS.find((s) => s.id === skinId) || SKINS[0]

  /* ---------------------- salva no localStorage ---------------------- */
  useEffect(() => LS.set('bp_best', best), [best])
  useEffect(() => LS.set('bp_coins', coins), [coins])
  useEffect(() => LS.set('bp_skin', skinId), [skinId])
  useEffect(() => LS.set('bp_owned', owned), [owned])

  /* --------------------- limpeza de timers / raf --------------------- */
  const clearTimers = useCallback(() => {
    timersRef.current.forEach(clearTimeout)
    timersRef.current = []
    if (rafRef.current) cancelAnimationFrame(rafRef.current)
    rafRef.current = null
  }, [])

  useEffect(() => clearTimers, [clearTimers])

  const later = useCallback((fn, ms) => {
    const id = setTimeout(fn, ms)
    timersRef.current.push(id)
    return id
  }, [])

  /* --------------------------- efeitos visuais ---------------------- */
  const doShake = useCallback(() => {
    setShake(true)
    later(() => setShake(false), 380)
  }, [later])

  const spawnParticles = useCallback(
    (x, y, colors) => {
      const items = Array.from({ length: 18 }, (_, i) => ({
        id: `${Date.now()}-${i}`,
        x,
        y,
        dx: (Math.random() - 0.5) * 220,
        dy: -Math.random() * 180 - 40,
        color: colors[i % colors.length],
        size: 6 + Math.random() * 8,
      }))
      setParticles(items)
      later(() => setParticles([]), 950)
    },
    [later]
  )

  /* ---------------------------- fim de jogo ------------------------- */
  const endGame = useCallback(
    (finalScore) => {
      setBest((b) => (finalScore > b ? finalScore : b))
      setScreen('over')
    },
    [setBest]
  )

  /* --------------------------- iniciar partida ---------------------- */
  const startGame = useCallback(() => {
    clearTimers()
    sound.unlock()
    setScore(0)
    setLives(LIVES_START)
    setPhase('aim')
    setMessage(null)
    setParticles([])
    setAdWatched(false)
    setBall({ ...BALL_HOME, scale: 1, spin: 0 })
    setKeeper({ x: KEEPER_SPOTS.center, dive: 'center', jumping: false })
    setScreen('game')
  }, [clearTimers, sound])

  /* ============================================================
     ADSENSE — ANÚNCIO EM VÍDEO / INTERSTICIAL (RECOMPENSADO)
     Hoje só devolve +3 vidas. Cole o código do vídeo aqui dentro.
     ============================================================ */
  const showVideoAd = useCallback(() => {
    // COLAR CODIGO ADSENSE VIDEO AQUI
    // DEPOIS DE FECHAR O VIDEO DAR +3 VIDAS
    if (!ADS_ENABLED) return
    setLives(3)
    setAdWatched(true)
    setPhase('aim')
    setMessage(null)
    setBall({ ...BALL_HOME, scale: 1, spin: 0 })
    setKeeper({ x: KEEPER_SPOTS.center, dive: 'center', jumping: false })
    setScreen('game')
    sound.crowd(1, 0.15)
  }, [sound])

  /* --------------------- IA DO GOLEIRO (aleatória) ------------------ */
  const pickDive = useCallback(() => {
    const options = ['left', 'center', 'right']
    return options[Math.floor(Math.random() * options.length)]
  }, [])

  /* ---------------------------- O CHUTE ----------------------------- */
  const shoot = useCallback(
    (targetX, targetY, power) => {
      setPhase('shooting')
      sound.kick()

      const currentLevel = Math.floor(score / GOALS_PER_LEVEL) + 1
      // nível maior = goleiro mais rápido (alcance maior e pulo mais cedo)
      const reach = Math.min(21, 9 + currentLevel * 1.4)
      const duration = Math.max(430, 850 - currentLevel * 32)
      const dive = pickDive()
      const keeperX = KEEPER_SPOTS[dive]

      // colisão simples bola x gol
      const dentroDoGol =
        targetX > GOAL.left && targetX < GOAL.right && targetY > GOAL.top && targetY < GOAL.bottom
      const chuteFraco = power < 0.26
      const altoDemais = targetY <= GOAL.top
      // colisão bola x goleiro
      const noAlcance = Math.abs(targetX - keeperX) <= reach
      const cantoAlto = targetY < GOAL.top + 8
      const defendeu = noAlcance && (!cantoAlto || Math.abs(targetX - keeperX) <= reach * 0.5)

      const gol = dentroDoGol && !chuteFraco && !defendeu

      // o goleiro pula 0,5s antes da bola chegar
      const diveDelay = Math.max(0, duration - 500)
      later(() => setKeeper({ x: keeperX, dive, jumping: true }), diveDelay)

      // animação do voo da bola
      const start = performance.now()
      const from = { ...BALL_HOME }
      const step = (now) => {
        const t = Math.min(1, (now - start) / duration)
        const ease = 1 - Math.pow(1 - t, 1.7)
        const arc = Math.sin(Math.PI * t) * 5 * power
        setBall({
          x: from.x + (targetX - from.x) * ease,
          y: from.y + (targetY - from.y) * ease - arc,
          scale: 1 - 0.45 * ease,
          spin: ease * 720 * (targetX > from.x ? 1 : -1),
        })
        if (t < 1) {
          rafRef.current = requestAnimationFrame(step)
        } else {
          finalize()
        }
      }

      const finalize = () => {
        setPhase('result')
        if (gol) {
          const novoScore = score + 1
          setScore(novoScore)
          setCoins((c) => c + COINS_PER_GOAL)
          setMessage({ type: 'goal', text: 'GOOOL!', sub: `+${COINS_PER_GOAL} moedas` })
          sound.muh()
          sound.crowd(1.6, 0.24)
          sound.coin()
          doShake()
          spawnParticles(targetX, targetY, ['#ffc71f', '#ffffff', '#6b3f1d', '#4ade80'])
          if (novoScore % GOALS_PER_LEVEL === 0) {
            later(
              () => setMessage({ type: 'level', text: `NÍVEL ${novoScore / GOALS_PER_LEVEL + 1}!`, sub: 'goleiro mais rápido' }),
              900
            )
          }
        } else {
          const motivo = defendeu
            ? 'O GOLEIRO PEGOU!'
            : chuteFraco
            ? 'CHUTE FRACO!'
            : altoDemais
            ? 'POR CIMA DO GOL!'
            : 'PRA FORA!'
          setMessage({ type: 'miss', text: motivo, sub: 'Perdeu 1 chifre' })
          sound.fail()
          doShake()
          setLives((v) => {
            const restantes = v - 1
            if (restantes <= 0) later(() => endGame(score), 900)
            return restantes
          })
        }

        // próximo pênalti
        later(() => {
          setMessage(null)
          setBall({ ...BALL_HOME, scale: 1, spin: 0 })
          setKeeper({ x: KEEPER_SPOTS.center, dive: 'center', jumping: false })
          setPhase('aim')
        }, 1400)
      }

      rafRef.current = requestAnimationFrame(step)
    },
    [score, sound, later, pickDive, doShake, spawnParticles, endGame]
  )

  /* ------------------- CONTROLE: CLIQUE E ARRASTE ------------------- */
  const onPointerDown = (e) => {
    if (phase !== 'aim') return
    sound.unlock()
    const rect = fieldRef.current.getBoundingClientRect()
    setDrag({ sx: e.clientX - rect.left, sy: e.clientY - rect.top, cx: e.clientX - rect.left, cy: e.clientY - rect.top })
  }

  const onPointerMove = (e) => {
    if (!drag || phase !== 'aim') return
    const rect = fieldRef.current.getBoundingClientRect()
    setDrag((d) => ({ ...d, cx: e.clientX - rect.left, cy: e.clientY - rect.top }))
  }

  const onPointerUp = () => {
    if (!drag || phase !== 'aim') return
    const rect = fieldRef.current.getBoundingClientRect()
    const dx = drag.cx - drag.sx
    const dy = drag.cy - drag.sy
    const dist = Math.hypot(dx, dy)
    setDrag(null)
    if (dist < 18) return // toque acidental: não chuta

    // direção e força do arraste definem o chute
    const power = Math.min(1, dist / (rect.height * 0.42))
    const targetX = Math.max(-15, Math.min(115, BALL_HOME.x + (dx / rect.width) * 190))
    const alturaRatio = Math.max(0, Math.min(1.25, -dy / (rect.height * 0.45)))
    const targetY = GOAL.bottom - alturaRatio * (GOAL.bottom - GOAL.top + 6)
    shoot(targetX, targetY, power)
  }

  /* ------------------------------ LOJA ------------------------------ */
  const buySkin = (item) => {
    if (owned.includes(item.id)) {
      setSkinId(item.id)
      sound.coin()
      return
    }
    if (coins < item.price) {
      sound.fail()
      return
    }
    setCoins((c) => c - item.price)
    setOwned((o) => [...o, item.id])
    setSkinId(item.id)
    sound.coin()
  }

  /* ----------------------- HUD / linha de mira ---------------------- */
  const aimLine = drag
    ? {
        length: Math.hypot(drag.cx - drag.sx, drag.cy - drag.sy),
        angle: (Math.atan2(drag.cy - drag.sy, drag.cx - drag.sx) * 180) / Math.PI,
      }
    : null

  const power = aimLine
    ? Math.min(100, Math.round((aimLine.length / ((fieldRef.current?.clientHeight || 500) * 0.42)) * 100))
    : 0

  /* ============================== RENDER ============================= */
  return (
    <div className="flex min-h-screen w-full justify-center bg-slate-900 font-game text-white">
      <div
        className={`relative flex w-full max-w-md flex-col ${shake ? 'shake' : ''}`}
        style={{ paddingBottom: ADS_ENABLED ? 56 : 0 }}
      >
        {/* ------------------------- TELA INICIAL ------------------------ */}
        {screen === 'home' && (
          <div className="flex min-h-screen flex-col items-center justify-between bg-gradient-to-b from-campoEscuro via-campo to-bufalo p-6">
            <div className="mt-8 pop-in">
              <Logo />
            </div>

            <div className="w-full space-y-3">
              <div className="flex justify-between gap-3">
                <div className="flex-1 rounded-2xl bg-black/35 p-3 text-center">
                  <p className="text-xs uppercase text-white/60">Recorde</p>
                  <p className="text-2xl font-extrabold text-amarelo">{best}</p>
                </div>
                <div className="flex-1 rounded-2xl bg-black/35 p-3 text-center">
                  <p className="text-xs uppercase text-white/60">Moedas</p>
                  <p className="text-2xl font-extrabold text-amarelo">🪙 {coins}</p>
                </div>
              </div>
              <BigButton onClick={startGame}>⚽ Jogar</BigButton>
              <BigButton tone="brown" onClick={() => setScreen('shop')}>
                🛒 Loja
              </BigButton>
              <p className="pt-1 text-center text-xs text-white/70">
                Arraste na tela para escolher direção e força do chute.
              </p>
            </div>
          </div>
        )}

        {/* --------------------------- LOJA ----------------------------- */}
        {screen === 'shop' && (
          <div className="flex min-h-screen flex-col bg-gradient-to-b from-bufalo to-campoEscuro p-5">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-extrabold text-amarelo">LOJA DE BOLAS</h2>
              <span className="rounded-full bg-black/40 px-3 py-1 text-sm font-bold text-amarelo">
                🪙 {coins}
              </span>
            </div>

            <div className="mt-4 flex-1 space-y-3">
              {SKINS.map((item) => {
                const isOwned = owned.includes(item.id)
                const isActive = skinId === item.id
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => buySkin(item)}
                    className={`flex w-full items-center gap-4 rounded-2xl border-b-4 p-4 text-left ${
                      isActive
                        ? 'border-amarelo bg-black/50 ring-2 ring-amarelo'
                        : 'border-black/40 bg-black/30'
                    }`}
                  >
                    <span
                      className="flex h-14 w-14 items-center justify-center rounded-full bg-white text-3xl"
                      style={{ boxShadow: `0 0 16px ${item.ring}` }}
                    >
                      {item.emoji}
                    </span>
                    <span className="flex-1">
                      <span className="block text-lg font-extrabold">{item.name}</span>
                      <span className="block text-sm text-white/70">
                        {isActive
                          ? 'Em uso'
                          : isOwned
                          ? 'Toque para equipar'
                          : item.price === 0
                          ? 'Grátis'
                          : `🪙 ${item.price} moedas`}
                      </span>
                    </span>
                    {!isOwned && item.price > coins && (
                      <span className="text-xs font-bold text-red-300">sem moedas</span>
                    )}
                  </button>
                )
              })}
            </div>

            <BigButton tone="yellow" onClick={() => setScreen('home')}>
              ← Voltar
            </BigButton>
          </div>
        )}

        {/* ------------------------- TELA DO JOGO ----------------------- */}
        {screen === 'game' && (
          <div className="relative flex min-h-screen flex-col">
            {/* HUD: placar, vidas, nível */}
            <div className="absolute inset-x-0 top-0 z-30 flex items-center justify-between px-4 pt-3">
              <div className="rounded-xl bg-black/45 px-3 py-1 text-center">
                <p className="text-[10px] uppercase text-white/60">Gols</p>
                <p className="text-xl font-extrabold text-amarelo">{score}</p>
              </div>
              <div className="rounded-xl bg-black/45 px-3 py-2">
                <Lives lives={lives} />
              </div>
              <div className="rounded-xl bg-black/45 px-3 py-1 text-center">
                <p className="text-[10px] uppercase text-white/60">Nível</p>
                <p className="text-xl font-extrabold text-amarelo">{level}</p>
              </div>
            </div>

            {/* campo jogável */}
            <div
              ref={fieldRef}
              onPointerDown={onPointerDown}
              onPointerMove={onPointerMove}
              onPointerUp={onPointerUp}
              onPointerLeave={onPointerUp}
              className="relative flex-1 touch-none"
              style={{ minHeight: '100vh' }}
            >
              <Stadium>
                <GoalFrame />
                <Keeper x={keeper.x} dive={keeper.dive} jumping={keeper.jumping} />
                <Ball x={ball.x} y={ball.y} scale={ball.scale} skin={skin} spin={ball.spin} />

                {/* linha de mira durante o arraste */}
                {aimLine && aimLine.length > 18 && (
                  <div
                    className="pointer-events-none absolute z-20 h-2 origin-left rounded-full bg-amarelo/80"
                    style={{
                      left: `${BALL_HOME.x}%`,
                      top: `${BALL_HOME.y}%`,
                      width: aimLine.length,
                      transform: `translateY(-50%) rotate(${aimLine.angle}deg)`,
                    }}
                  />
                )}

                {/* partículas do gol */}
                {particles.map((p) => (
                  <span
                    key={p.id}
                    className="particle pointer-events-none absolute z-30 rounded-sm"
                    style={{
                      left: `${p.x}%`,
                      top: `${p.y}%`,
                      width: p.size,
                      height: p.size,
                      background: p.color,
                      '--dx': `${p.dx}px`,
                      '--dy': `${p.dy}px`,
                    }}
                  />
                ))}
              </Stadium>

              {/* barra de força */}
              {phase === 'aim' && (
                <div className="absolute bottom-24 left-1/2 z-30 w-52 -translate-x-1/2">
                  <div className="h-3 w-full overflow-hidden rounded-full bg-black/50">
                    <div
                      className="h-full bg-gradient-to-r from-lime-400 via-amarelo to-red-500 transition-[width] duration-75"
                      style={{ width: `${power}%` }}
                    />
                  </div>
                  <p className="mt-2 text-center text-xs font-bold text-white/80">
                    {drag ? 'SOLTE PRA CHUTAR!' : 'ARRASTE PARA CHUTAR'}
                  </p>
                </div>
              )}

              {/* mensagem de resultado */}
              {message && (
                <div className="pointer-events-none absolute inset-0 z-40 flex flex-col items-center justify-center">
                  <p
                    className={`float-up text-stroke text-5xl font-extrabold ${
                      message.type === 'miss' ? 'text-red-400' : 'text-amarelo'
                    }`}
                  >
                    {message.text}
                  </p>
                  <p className="text-sm font-bold text-white/90">{message.sub}</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ------------------------ TELA GAME OVER ---------------------- */}
        {screen === 'over' && (
          <div className="flex min-h-screen flex-col items-center justify-center gap-5 bg-gradient-to-b from-black via-bufalo to-campoEscuro p-6">
            <div className="pop-in text-center">
              <div className="text-6xl">🐃💥</div>
              <h2 className="text-stroke mt-2 text-4xl font-extrabold text-red-400">
                O BÚFALO ERROU!
              </h2>
            </div>

            <div className="w-full space-y-3">
              <div className="flex gap-3">
                <div className="flex-1 rounded-2xl bg-black/40 p-4 text-center">
                  <p className="text-xs uppercase text-white/60">Pontuação</p>
                  <p className="text-3xl font-extrabold text-white">{score}</p>
                </div>
                <div className="flex-1 rounded-2xl bg-black/40 p-4 text-center">
                  <p className="text-xs uppercase text-white/60">Recorde</p>
                  <p className="text-3xl font-extrabold text-amarelo">{best}</p>
                </div>
              </div>
              <p className="text-center text-sm text-white/70">🪙 Moedas: {coins}</p>

              <BigButton onClick={startGame}>🔁 Jogar novamente</BigButton>

              {/* ADSENSE — BOTÃO DE VÍDEO RECOMPENSADO (+3 VIDAS) */}
              {ADS_ENABLED && (
                <BigButton tone="green" onClick={showVideoAd} disabled={adWatched}>
                  {adWatched ? 'Anúncio já usado' : '▶ Assistir anúncio para +3 vidas'}
                </BigButton>
              )}

              <BigButton tone="brown" onClick={() => setScreen('shop')}>
                🛒 Loja
              </BigButton>
              <BigButton tone="dark" onClick={() => setScreen('home')}>
                🏠 Menu
              </BigButton>
            </div>
          </div>
        )}

        {/* ---------------- BANNER ADSENSE FIXO (RODAPÉ) ---------------- */}
        <BannerAd />
      </div>
    </div>
  )
}
