/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        campo: '#1f7a34',
        campoEscuro: '#155e27',
        bufalo: '#6b3f1d',
        bufaloClaro: '#a9702f',
        amarelo: '#ffc71f',
      },
      fontFamily: {
        game: ['"Trebuchet MS"', 'Impact', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
