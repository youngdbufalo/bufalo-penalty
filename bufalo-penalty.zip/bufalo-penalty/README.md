# BÚFALO PENALTY ⚽🐃

> "Chuta forte ou volta pro banco!"

Jogo hyper casual de pênaltis infinitos em React + Vite + Tailwind (JavaScript).
Todo o jogo está em **um único arquivo**: `src/App.jsx`.

## Rodar

```bash
npm install
npm run dev      # desenvolvimento
npm run build    # gera a pasta dist/ para publicar
```

A pasta `dist/` já vem pronta neste pacote (usa caminhos relativos, então
funciona em qualquer hospedagem: Netlify, Vercel, GitHub Pages, hospedagem
compartilhada, etc.).

## Como jogar

Clique/toque e arraste na tela: a **direção** do arraste é a direção do chute e
o **tamanho** do arraste é a força (veja a barra de força). Solte para chutar.

- Cada gol: +1 ponto e +10 moedas
- A cada 5 gols: sobe 1 nível e o goleiro fica mais rápido (mais alcance e pulo mais cedo)
- 3 vidas (chifres de búfalo). Sem chifres = Game Over
- Recorde, moedas, skins compradas e skin equipada ficam salvos no `localStorage`

## Onde colar o Google AdSense

1. **Script da conta** — `index.html`, no comentário
   `<!-- COLAR CODIGO ADSENSE (SCRIPT DA CONTA) AQUI -->`
2. **Banner fixo no rodapé** — `src/App.jsx`, componente `BannerAd`,
   dentro da div `#banner-ad`, no comentário
   `{/* COLAR CODIGO ADSENSE BANNER AQUI */}`
3. **Vídeo / intersticial (+3 vidas)** — `src/App.jsx`, função `showVideoAd()`,
   nos comentários `// COLAR CODIGO ADSENSE VIDEO AQUI` e
   `// DEPOIS DE FECHAR O VIDEO DAR +3 VIDAS`
4. **Liga/desliga geral** — constante `const ADS_ENABLED = true` no topo de `App.jsx`

## Estrutura

```
index.html            # viewport mobile + espaço do script AdSense
src/App.jsx           # jogo completo (telas, física, IA do goleiro, loja, ads)
src/index.css         # Tailwind + animações (tremor de tela, partículas)
tailwind.config.js    # cores do tema: campo, búfalo, amarelo
```

Sons são gerados via WebAudio (MUH do búfalo, torcida, chute, moeda), então não
existe nenhum arquivo de áudio para baixar.
